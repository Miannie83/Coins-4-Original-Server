class Category_493 {
	class CH_47F_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {400000,"Coins"};
		sell[] = {133333,"Coins"};
	};
	class UH1H_DZE {
		type = "trade_any_vehicle";
		buy[] = {200000,"Coins"};
		sell[] = {66666,"Coins"};
	};
	class Mi17_DZE {
		type = "trade_any_vehicle";
		buy[] = {200000,"Coins"};
		sell[] = {66666,"Coins"};
	};
	class UH60M_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {200000,"Coins"};
		sell[] = {66666,"Coins"};
	};
	class UH1Y_DZE {
		type = "trade_any_vehicle";
		buy[] = {200000,"Coins"};
		sell[] = {66666,"Coins"};
	};
	class MH60S_DZE {
		type = "trade_any_vehicle";
		buy[] = {200000,"Coins"};
		sell[] = {66666,"Coins"};
	};
	class CH53_DZE {
		type = "trade_any_vehicle";
		buy[] = {400000,"Coins"};
		sell[] = {133333,"Coins"};
	};
};
