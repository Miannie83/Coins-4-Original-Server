class Category_569 {
	class HMMWV_M998A2_SOV_DES_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {250000,"Coins"};
		sell[] = {30000,"Coins"};
	};
	class HMMWV_M1151_M2_CZ_DES_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {650000,"Coins"};
		sell[] = {45000,"Coins"};
	};
	class LandRover_Special_CZ_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {250000,"Coins"};
		sell[] = {25000,"Coins"};
	};
	class LandRover_MG_TK_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {85000,"Coins"};
		sell[] = {7000,"Coins"};
	};
	class UAZ_MG_TK_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {85000,"Coins"};
		sell[] = {7000,"Coins"};
	};
	class GAZ_Vodnik_DZE {
		type = "trade_any_vehicle";
		buy[] = {350000,"Coins"};
		sell[] = {15000,"Coins"};
	};
};
