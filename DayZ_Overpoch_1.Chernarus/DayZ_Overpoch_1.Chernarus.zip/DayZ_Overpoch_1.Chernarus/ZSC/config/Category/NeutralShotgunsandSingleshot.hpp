class Category_607 {
	class Winchester1866 {
		type = "trade_weapons";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
	class MR43 {
		type = "trade_weapons";
		buy[] = {100,"Coins"};
		sell[] = {15,"Coins"};
	};
	class Crossbow_DZ {
		type = "trade_weapons";
		buy[] = {100,"Coins"};
		sell[] = {15,"Coins"};
	};
	class M1014 {
		type = "trade_weapons";
		buy[] = {3000,"Coins"};
		sell[] = {375,"Coins"};
	};
	class Remington870_lamp {
		type = "trade_weapons";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class LeeEnfield {
		type = "trade_weapons";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
};
class Category_641 {
	class Winchester1866 {
		type = "trade_weapons";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
	class MR43 {
		type = "trade_weapons";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
	class Crossbow_DZ {
		type = "trade_weapons";
		buy[] = {100,"Coins"};
		sell[] = {15,"Coins"};
	};
	class M1014 {
		type = "trade_weapons";
		buy[] = {3000,"Coins"};
		sell[] = {375,"Coins"};
	};
	class Remington870_lamp {
		type = "trade_weapons";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class LeeEnfield {
		type = "trade_weapons";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
};
