class Category_1016 {
	class CVPI_Patrol {
	type = "trade_any_vehicle";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class CVPI_Trooper_Patrol {
	type = "trade_any_vehicle";
	buy[] = {200000,"Coins"};
	sell[] = {25000,"Coins"};
	};
	class CVPI_TrooperSL_Patrol {
	type = "trade_any_vehicle";
	buy[] = {200000,"Coins"};
	sell[] = {25000,"Coins"};
	};
	class CVPI_NYPD_Patrol {
	type = "trade_any_vehicle";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class CVPI_HighwaySL_Patrol {
	type = "trade_any_vehicle";
	buy[] = {200000,"Coins"};
	sell[] = {25000,"Coins"};
	};
	class CVPI_UnmarkedB_Patrol {
	type = "trade_any_vehicle";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class CVPI_UnmarkedG_Patrol {
	type = "trade_any_vehicle";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class CVPI_LAPD_Patrol {
	type = "trade_any_vehicle";
	buy[] = {200000,"Coins"};
	sell[] = {25000,"Coins"};
	};
	class CVPI_UnmarkedW_Patrol {
	type = "trade_any_vehicle";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class CVPI_LAPDSL_Patrol {
	type = "trade_any_vehicle";
	buy[] = {200000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class CVPI_NYPDSL_Patrol {
	type = "trade_any_vehicle";
	buy[] = {200000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class policecar {
	type = "trade_any_vehicle";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class Copcar {
	type = "trade_any_vehicle";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class Copcarhw {
	type = "trade_any_vehicle";
	buy[] = {200000,"Coins"};
	sell[] = {25000,"Coins"};
	};
	class Copcarswat {
	type = "trade_any_vehicle";
	buy[] = {200000,"Coins"};
	sell[] = {25000,"Coins"};
	};
};