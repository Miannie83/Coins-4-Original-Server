class Category_512 {
	class CH_47F_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {650000,"Coins"};
		sell[] = {100000,"Coins"};
	};
	class UH1H_DZE {
		type = "trade_any_vehicle";
		buy[] = {350000,"Coins"};
		sell[] = {50000,"Coins"};
	};
	class Mi17_DZE {
		type = "trade_any_vehicle";
		buy[] = {350000,"Coins"};
		sell[] = {50000,"Coins"};
	};
	class UH60M_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {450000,"Coins"};
		sell[] = {50000,"Coins"};
	};
	class UH1Y_DZE {
		type = "trade_any_vehicle";
		buy[] = {350000,"Coins"};
		sell[] = {50000,"Coins"};
	};
	class MH60S_DZE {
		type = "trade_any_vehicle";
		buy[] = {350000,"Coins"};
		sell[] = {50000,"Coins"};
	};
	class CH53_DZE {
		type = "trade_any_vehicle";
		buy[] = {650000,"Coins"};
		sell[] = {100000,"Coins"};
	};
};
