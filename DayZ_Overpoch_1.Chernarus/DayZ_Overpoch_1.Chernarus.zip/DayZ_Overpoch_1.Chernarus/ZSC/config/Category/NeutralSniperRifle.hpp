class Category_605 {
	class SVD_CAMO {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class M40A3 {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class M14_EP1 {
		type = "trade_weapons";
		buy[] = {20000,"Coins"};
		sell[] = {2500,"Coins"};
	};
	class huntingrifle {
		type = "trade_weapons";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class M4SPR {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class SVD {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class SVD_des_EP1 {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class M24 {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class M24_des_EP1 {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
};
class Category_640 {
	class SVD_CAMO {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class M40A3 {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class M14_EP1 {
		type = "trade_weapons";
		buy[] = {20000,"Coins"};
		sell[] = {2500,"Coins"};
	};
	class huntingrifle {
		type = "trade_weapons";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class M4SPR {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class SVD {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class SVD_des_EP1 {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class M24 {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class M24_des_EP1 {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
};
