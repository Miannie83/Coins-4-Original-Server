class Category_686 {
	class FoodbaconCooked {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {20,"Coins"};
	};
	class FoodbeefCooked {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {20,"Coins"};
	};
	class FoodchickenCooked {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {20,"Coins"};
	};
	class FoodmuttonCooked {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {20,"Coins"};
	};
	class FoodrabbitCooked {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemTroutCooked {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemSeaBassCooked {
		type = "trade_items";
		buy[] = {30,"Coins"};
		sell[] = {20,"Coins"};
	};
	class ItemTunaCooked {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {10,"Coins"};
	};
};
class Category_580 {
	class FoodbaconCooked {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {20,"Coins"};
	};
	class FoodbeefCooked {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {20,"Coins"};
	};
	class FoodchickenCooked {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {20,"Coins"};
	};
	class FoodmuttonCooked {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {20,"Coins"};
	};
	class FoodrabbitCooked {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemTroutCooked {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemSeaBassCooked {
		type = "trade_items";
		buy[] = {30,"Coins"};
		sell[] = {20,"Coins"};
	};
	class ItemTunaCooked {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {10,"Coins"};
	};
};
class Category_634 {
	class FoodbaconCooked {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {20,"Coins"};
	};
	class FoodbeefCooked {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {20,"Coins"};
	};
	class FoodchickenCooked {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {20,"Coins"};
	};
	class FoodmuttonCooked {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {20,"Coins"};
	};
	class FoodrabbitCooked {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemTroutCooked {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemSeaBassCooked {
		type = "trade_items";
		buy[] = {30,"Coins"};
		sell[] = {20,"Coins"};
	};
	class ItemTunaCooked {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {10,"Coins"};
	};
};
