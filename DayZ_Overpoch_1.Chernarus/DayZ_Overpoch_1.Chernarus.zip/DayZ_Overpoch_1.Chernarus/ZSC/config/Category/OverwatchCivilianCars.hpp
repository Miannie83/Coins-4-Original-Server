class Category_1015 {
class Civcar {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class Civcarbu {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class civcarbl {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class Civcarre {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class Civcarge {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class Civcarwh {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class Civcarsl {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class 350z {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class 350z_red {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class 350z_kiwi {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class 350z_black {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class 350z_silver {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class 350z_green {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class 350z_blue {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class 350z_gold {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class 350z_white {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class 350z_pink {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class 350z_mod {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class 350z_ruben {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class 350z_v {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class 350z_city {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
class 350z_yellow {
type = "trade_any_vehicle";
buy[] = {30000,"Coins"};
sell[] = {3750,"Coins"};
};
};