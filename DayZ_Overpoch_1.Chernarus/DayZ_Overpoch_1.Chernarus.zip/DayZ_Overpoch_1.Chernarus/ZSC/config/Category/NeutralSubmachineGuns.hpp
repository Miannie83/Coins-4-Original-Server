class Category_604 {
	class bizon_silenced {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class UZI_EP1 {
		type = "trade_weapons";
		buy[] = {4000,"Coins"};
		sell[] = {500,"Coins"};
	};
	class Sa61_EP1 {
		type = "trade_weapons";
		buy[] = {1000,"Coins"};
		sell[] = {125,"Coins"};
	};
	class MP5A5 {
		type = "trade_weapons";
		buy[] = {1000,"Coins"};
		sell[] = {125,"Coins"};
	};
	class UZI_SD_EP1 {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class MP5SD {
		type = "trade_weapons";
		buy[] = {6000,"Coins"};
		sell[] = {750,"Coins"};
	};
};
class Category_642 {
	class bizon_silenced {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class UZI_EP1 {
		type = "trade_weapons";
		buy[] = {4000,"Coins"};
		sell[] = {500,"Coins"};
	};
	class Sa61_EP1 {
		type = "trade_weapons";
		buy[] = {1000,"Coins"};
		sell[] = {125,"Coins"};
	};
	class MP5A5 {
		type = "trade_weapons";
		buy[] = {1000,"Coins"};
		sell[] = {125,"Coins"};
	};
	class UZI_SD_EP1 {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class MP5SD {
		type = "trade_weapons";
		buy[] = {6000,"Coins"};
		sell[] = {750,"Coins"};
	};
};
