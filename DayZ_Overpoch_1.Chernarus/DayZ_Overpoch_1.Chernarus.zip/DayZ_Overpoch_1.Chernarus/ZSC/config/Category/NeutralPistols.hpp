class Category_606 {
	class M9SD {
		type = "trade_weapons";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class glock17_EP1 {
		type = "trade_weapons";
		buy[] = {1000,"Coins"};
		sell[] = {120,"Coins"};
	};
	class Colt1911 {
		type = "trade_weapons";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
	class M9 {
		type = "trade_weapons";
		buy[] = {1000,"Coins"};
		sell[] = {125,"Coins"};
	};
	class MakarovSD {
		type = "trade_weapons";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class revolver_gold_EP1 {
		type = "trade_weapons";
		buy[] = {3000,"Coins"};
		sell[] = {375,"Coins"};
	};
	class Makarov {
		type = "trade_weapons";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
	class revolver_EP1 {
		type = "trade_weapons";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
};
class Category_674 {
	class M9SD {
		type = "trade_weapons";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class glock17_EP1 {
		type = "trade_weapons";
		buy[] = {1000,"Coins"};
		sell[] = {125,"Coins"};
	};
	class Colt1911 {
		type = "trade_weapons";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
	class M9 {
		type = "trade_weapons";
		buy[] = {1000,"Coins"};
		sell[] = {15,"Coins"};
	};
	class MakarovSD {
		type = "trade_weapons";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
	class revolver_gold_EP1 {
		type = "trade_weapons";
		buy[] = {3000,"Coins"};
		sell[] = {375,"Coins"};
	};
	class Makarov {
		type = "trade_weapons";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
	class revolver_EP1 {
		type = "trade_weapons";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
};
