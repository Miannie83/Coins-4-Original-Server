class Category_517 {
	class AN2_DZ {
		type = "trade_any_vehicle";
		buy[] = {40000,"Coins"};
		sell[] = {10000,"Coins"};
	};
	class C130J_US_EP1_DZ {
		type = "trade_any_vehicle";
		buy[] = {400000,"Coins"};
		sell[] = {100000,"Coins"};
	};
	class MV22_DZ {
		type = "trade_any_vehicle";
		buy[] = {500000,"Coins"};
		sell[] = {125000,"Coins"};
	};
	class GNT_C185U {
		type = "trade_any_vehicle";
		buy[] = {40000,"Coins"};
		sell[] = {10000,"Coins"};
	};
	class GNT_C185 {
		type = "trade_any_vehicle";
		buy[] = {40000,"Coins"};
		sell[] = {10000,"Coins"};
	};
	class GNT_C185R {
		type = "trade_any_vehicle";
		buy[] = {40000,"Coins"};
		sell[] = {10000,"Coins"};
	};
	class GNT_C185C {
		type = "trade_any_vehicle";
		buy[] = {40000,"Coins"};
		sell[] = {10000,"Coins"};
	};
};
