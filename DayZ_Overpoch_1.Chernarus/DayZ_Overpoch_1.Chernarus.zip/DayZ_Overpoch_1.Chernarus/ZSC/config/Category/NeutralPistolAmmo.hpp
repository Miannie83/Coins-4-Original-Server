class Category_646 {
	class 15Rnd_9x19_M9 {
		type = "trade_items";
		buy[] = {100,"Coins"};
		sell[] = {15,"Coins"};
	};
	class 15Rnd_9x19_M9SD {
		type = "trade_items";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
	class 17Rnd_9x19_glock17 {
		type = "trade_items";
		buy[] = {100,"Coins"};
		sell[] = {15,"Coins"};
	};
	class 6Rnd_45ACP {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class 7Rnd_45ACP_1911 {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class 8Rnd_9x18_Makarov {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class 8Rnd_9x18_MakarovSD {
		type = "trade_items";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
};
class Category_611 {
	class 15Rnd_9x19_M9 {
		type = "trade_items";
		buy[] = {100,"Coins"};
		sell[] = {15,"Coins"};
	};
	class 15Rnd_9x19_M9SD {
		type = "trade_items";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
	class 17Rnd_9x19_glock17 {
		type = "trade_items";
		buy[] = {100,"Coins"};
		sell[] = {15,"Coins"};
	};
	class 6Rnd_45ACP {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class 7Rnd_45ACP_1911 {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class 8Rnd_9x18_Makarov {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class 8Rnd_9x18_MakarovSD {
		type = "trade_items";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
};
