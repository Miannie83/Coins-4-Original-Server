class Category_1004 {
	class SCAR_H_CQC_CCO {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class SCAR_H_CQC_CCO_SD {
	type = "trade_weapons";
	buy[] = {30000,"Coins"};
	sell[] = {3750,"Coins"};
	};
	class SCAR_H_STD_EGLM_Spect {
	type = "trade_weapons";
	buy[] = {30000,"Coins"};
	sell[] = {3750,"Coins"};
	};
	class SCAR_L_CQC {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class SCAR_L_CQC_CCO_SD {
	type = "trade_weapons";
	buy[] = {30000,"Coins"};
	sell[] = {3750,"Coins"};
	};
	class SCAR_L_CQC_EGLM_Holo {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class SCAR_L_CQC_Holo {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class SCAR_L_STD_EGLM_RCO {
	type = "trade_weapons";
	buy[] = {30000,"Coins"};
	sell[] = {3750,"Coins"};
	};
	class SCAR_L_STD_HOLO {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class SCAR_L_STD_Mk4CQT {
	type = "trade_weapons";
	buy[] = {30000,"Coins"};
	sell[] = {3750,"Coins"};
	};
};