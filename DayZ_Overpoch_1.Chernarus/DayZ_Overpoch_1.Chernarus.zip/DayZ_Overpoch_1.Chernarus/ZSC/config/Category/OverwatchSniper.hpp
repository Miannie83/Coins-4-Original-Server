class Category_1011 {
	class SCAR_H_LNG_Sniper {
	type = "trade_weapons";
	buy[] = {60000,"Coins"};
	sell[] = {7500,"Coins"};
	};
	class vil_SR25 {
	type = "trade_weapons";
	buy[] = {60000,"Coins"};
	sell[] = {7500,"Coins"};
	};
	class vil_SR25SD {
	type = "trade_weapons";
	buy[] = {70000,"Coins"};
	sell[] = {8750,"Coins"};
	};
	class vil_SV_98 {
	type = "trade_weapons";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class vil_SV_98_69 {
	type = "trade_weapons";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class vil_SV_98_SD {
	type = "trade_weapons";
	buy[] = {200000,"Coins"};
	sell[] = {25000,"Coins"};
	};
	class RH_sc2shd {
	type = "trade_weapons";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class RH_sc2sp {
	type = "trade_weapons";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class vil_G3sg1b {
	type = "trade_weapons";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class DMR_DZ {
	type = "trade_weapons";
	buy[] = {60000,"Coins"};
	sell[] = {7500,"Coins"};
	};
	class gms_k98 {
	type = "trade_weapons";
	buy[] = {50000,"Coins"};
	sell[] = {6250,"Coins"};
	};
	class gms_k98zf39 {
	type = "trade_weapons";
	buy[] = {50000,"Coins"};
	sell[] = {6250,"Coins"};
	};
	class gms_k98_knife {
	type = "trade_weapons";
	buy[] = {50000,"Coins"};
	sell[] = {6250,"Coins"};
	};
	class gms_k98_rg {
	type = "trade_weapons";
	buy[] = {50000,"Coins"};
	sell[] = {6250,"Coins"};
	};
	class SCAR_H_LNG_Sniper_SD {
	type = "trade_weapons";
	buy[] = {70000,"Coins"};
	sell[] = {8750,"Coins"};
	};
	class vil_SKS {
	type = "trade_weapons";
	buy[] = {70000,"Coins"};
	sell[] = {8750,"Coins"};
	};
	class vil_SVDK {
	type = "trade_weapons";
	buy[] = {80000,"Coins"};
	sell[] = {10000,"Coins"};
	};
	class vil_SVD_63 {
	type = "trade_weapons";
	buy[] = {50000,"Coins"};
	sell[] = {6250,"Coins"};
	};
	class vil_SVD_M {
	type = "trade_weapons";
	buy[] = {60000,"Coins"};
	sell[] = {7500,"Coins"};
	};
	class vil_SVD_N {
	type = "trade_weapons";
	buy[] = {70000,"Coins"};
	sell[] = {8750,"Coins"};
	};
	class vil_SVD_P21 {
	type = "trade_weapons";
	buy[] = {80000,"Coins"};
	sell[] = {10000,"Coins"};
	};
	class vil_SVD_S {
	type = "trade_weapons";
	buy[] = {90000,"Coins"};
	sell[] = {11250,"Coins"};
	};
	class FHQ_MSR_DESERT {
	type = "trade_weapons";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class RH_sc2 {
	type = "trade_weapons";
	buy[] = {80000,"Coins"};
	sell[] = {10000,"Coins"};
	};
	class RH_sc2acog {
	type = "trade_weapons";
	buy[] = {90000,"Coins"};
	sell[] = {11250,"Coins"};
	};
	class RH_sc2aim {
	type = "trade_weapons";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class RH_sc2eot {
	type = "trade_weapons";
	buy[] = {90000,"Coins"};
	sell[] = {11250,"Coins"};
	};
	class RH_m14 {
	type = "trade_weapons";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class RH_m14acog {
	type = "trade_weapons";
	buy[] = {30000,"Coins"};
	sell[] = {3750,"Coins"};
	};
	class RH_m14aim {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class RH_m14eot {
	type = "trade_weapons";
	buy[] = {40000,"Coins"};
	sell[] = {5000,"Coins"};
	};
	class vil_vsk94 {
	type = "trade_weapons";
	buy[] = {50000,"Coins"};
	sell[] = {6250,"Coins"};
	};
	class RH_hk417sp {
	type = "trade_weapons";
	buy[] = {70000,"Coins"};
	sell[] = {8750,"Coins"};
	};
	class vil_G3SG1 {
	type = "trade_weapons";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class RH_m1s {
	type = "trade_weapons";
	buy[] = {50000,"Coins"};
	sell[] = {6250,"Coins"};
	};
	class RH_m1sacog {
	type = "trade_weapons";
	buy[] = {60000,"Coins"};
	sell[] = {7500,"Coins"};
	};
	class RH_m1saim {
	type = "trade_weapons";
	buy[] = {70000,"Coins"};
	sell[] = {8750,"Coins"};
	};
	class RH_m1seot {
	type = "trade_weapons";
	buy[] = {70000,"Coins"};
	sell[] = {8750,"Coins"};
	};
	class RH_m1sshd {
	type = "trade_weapons";
	buy[] = {90000,"Coins"};
	sell[] = {11250,"Coins"};
	};
	class RH_m1ssp {
	type = "trade_weapons";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class RH_m1stacog {
	type = "trade_weapons";
	buy[] = {90000,"Coins"};
	sell[] = {11250,"Coins"};
	};
	class RH_m1staim {
	type = "trade_weapons";
	buy[] = {90000,"Coins"};
	sell[] = {11250,"Coins"};
	};
	class RH_m1steot {
	type = "trade_weapons";
	buy[] = {90000,"Coins"};
	sell[] = {11250,"Coins"};
	};
	class RH_m1stshd {
	type = "trade_weapons";
	buy[] = {90000,"Coins"};
	sell[] = {11250,"Coins"};
	};
	class vil_HK417s {
	type = "trade_weapons";
	buy[] = {70000,"Coins"};
	sell[] = {8750,"Coins"};
	};
	class USSR_cheytacM200 {
	type = "trade_weapons";
	buy[] = {300000,"Coins"};
	sell[] = {37500,"Coins"};
	};
	class USSR_cheytacM200_sd {
	type = "trade_weapons";
	buy[] = {300000,"Coins"};
	sell[] = {37500,"Coins"};
	};
	class FHQ_MSR_NV_DESERT {
	type = "trade_weapons";
	buy[] = {300000,"Coins"};
	sell[] = {37500,"Coins"};
	};
	class FHQ_MSR_NV_SD_DESERT {
	type = "trade_weapons";
	buy[] = {300000,"Coins"};
	sell[] = {37500,"Coins"};
	};
	class FHQ_MSR_SD_DESERT {
	type = "trade_weapons";
	buy[] = {300000,"Coins"};
	sell[] = {37500,"Coins"};
	};
	class FHQ_RSASS_SD_TAN {
	type = "trade_weapons";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class FHQ_RSASS_TAN {
	type = "trade_weapons";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class FHQ_XM2010_DESERT {
	type = "trade_weapons";
	buy[] = {200000,"Coins"};
	sell[] = {25000,"Coins"};
	};
	class FHQ_XM2010_NV_DESERT {
	type = "trade_weapons";
	buy[] = {200000,"Coins"};
	sell[] = {25000,"Coins"};
	};
	class FHQ_XM2010_NV_SD_DESERT {
	type = "trade_weapons";
	buy[] = {200000,"Coins"};
	sell[] = {25000,"Coins"};
	};
	class FHQ_XM2010_SD_DESERT {
	type = "trade_weapons";
	buy[] = {200000,"Coins"};
	sell[] = {25000,"Coins"};
	};
	class RH_m21 {
	type = "trade_weapons";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class vil_M110 {
	type = "trade_weapons";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class vil_M110sd {
	type = "trade_weapons";
	buy[] = {100000,"Coins"};
	sell[] = {12500,"Coins"};
	};
	class vil_M14G {
	type = "trade_weapons";
	buy[] = {200000,"Coins"};
	sell[] = {25000,"Coins"};
	};
	class vil_M21G {
	type = "trade_weapons";
	buy[] = {200000,"Coins"};
	sell[] = {25000,"Coins"};
	};
	class RH_m1st {
	type = "trade_weapons";
	buy[] = {90000,"Coins"};
	sell[] = {11250,"Coins"};
	};
	class RH_m1stsp {
	type = "trade_weapons";
	buy[] = {200000,"Coins"};
	sell[] = {25000,"Coins"};
	};
	class vil_Groza_SC {
	type = "trade_weapons";
	buy[] = {200000,"Coins"};
	sell[] = {25000,"Coins"};
	};
};
