class Category_664 {
	class ItemJerrycan {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {20,"Coins"};
	};
	class ItemJerrycanEmpty {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class PartEngine {
		type = "trade_items";
		buy[] = {5000,"Coins"};
		sell[] = {625,"Coins"};
	};
	class PartVRotor {
		type = "trade_items";
		buy[] = {5000,"Coins"};
		sell[] = {625,"Coins"};
	};
	class PartWheel {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class PartGlass {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {113,"Coins"};
	};
	class PartGeneric {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class PartFueltank {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class ItemFuelBarrel {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
};
class Category_509 {
	class ItemJerrycan {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {20,"Coins"};
	};
	class ItemJerrycanEmpty {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class PartEngine {
		type = "trade_items";
		buy[] = {5000,"Coins"};
		sell[] = {625,"Coins"};
	};
	class PartVRotor {
		type = "trade_items";
		buy[] = {5000,"Coins"};
		sell[] = {625,"Coins"};
	};
	class PartWheel {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class PartGlass {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {113,"Coins"};
	};
	class PartGeneric {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class PartFueltank {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class ItemFuelBarrel {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
};
