class Category_687 {
	class FoodCanBakedBeans {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class FoodCanFrankBeans {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class FoodCanPasta {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {1,"Coins"};
	};
	class FoodCanSardines {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class FoodMRE {
		type = "trade_items";
		buy[] = {10,"Coins"};
		sell[] = {5,"Coins"};
	};
	class FoodPistachio {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class FoodNutmix {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
};
class Category_579 {
	class FoodCanBakedBeans {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class FoodCanFrankBeans {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class FoodCanPasta {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class FoodCanSardines {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class FoodMRE {
		type = "trade_items";
		buy[] = {50,"Coins"};
		sell[] = {10,"Coins"};
	};
	class FoodPistachio {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class FoodNutmix {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
};
class Category_635 {
	class FoodCanBakedBeans {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class FoodCanFrankBeans {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class FoodCanPasta {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class FoodCanSardines {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class FoodMRE {
		type = "trade_items";
		buy[] = {50,"Coins"};
		sell[] = {5,"Coins"};
	};
	class FoodPistachio {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class FoodNutmix {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
};
