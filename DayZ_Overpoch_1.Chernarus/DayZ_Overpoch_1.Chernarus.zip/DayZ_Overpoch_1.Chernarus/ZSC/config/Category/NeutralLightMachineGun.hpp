class Category_603 {
	class M249_EP1_DZ {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class M240_DZ {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class Mk_48_DZ {
		type = "trade_weapons";
		buy[] = {20000,"Coins"};
		sell[] = {2500,"Coins"};
	};
	class Pecheneg_DZ {
		type = "trade_weapons";
		buy[] = {20000,"Coins"};
		sell[] = {2500,"Coins"};
	};
			class M249_DZ {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
};
class Category_638 {
	class M249_EP1_DZ {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class M240_DZ {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class Mk_48_DZ {
		type = "trade_weapons";
		buy[] = {20000,"Coins"};
		sell[] = {2500,"Coins"};
	};
	class Pecheneg_DZ {
		type = "trade_weapons";
		buy[] = {20000,"Coins"};
		sell[] = {2500,"Coins"};
	};
		class M249_DZ {
		type = "trade_weapons";
		buy[] = {10000,"Coins"};
		sell[] = {1250,"Coins"};
	};
};
