class Category_902 {
	class ItemRadio {
		type = "trade_items";
		buy[] = {200,"Coins"};
		sell[] = {10,"Coins"};
	};
};
