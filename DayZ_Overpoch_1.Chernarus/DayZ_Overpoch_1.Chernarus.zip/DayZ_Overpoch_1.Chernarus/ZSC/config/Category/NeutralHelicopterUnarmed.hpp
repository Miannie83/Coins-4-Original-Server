class Category_519 {
	class Mi17_Civilian_DZ {
		type = "trade_any_vehicle";
		buy[] = {200000,"Coins"};
		sell[] = {50000,"Coins"};
	};
	class AH6X_DZ {
		type = "trade_any_vehicle";
		buy[] = {60000,"Coins"};
		sell[] = {15000,"Coins"};
	};
	class MH6J_DZ {
		type = "trade_any_vehicle";
		buy[] = {80000,"Coins"};
		sell[] = {20000,"Coins"};
	};
	class CSJ_GyroC {
		type = "trade_any_vehicle";
		buy[] = {4000,"Coins"};
		sell[] = {1000,"Coins"};
	};
	class CSJ_GyroCover {
		type = "trade_any_vehicle";
		buy[] = {4000,"Coins"};
		sell[] = {1000,"Coins"};
	};
	class CSJ_GyroP {
		type = "trade_any_vehicle";
		buy[] = {5000,"Coins"};
		sell[] = {1250,"Coins"};
	};
	class BAF_Merlin_DZE {
		type = "trade_any_vehicle";
		buy[] = {200000,"Coins"};
		sell[] = {50000,"Coins"};
	};
	class CH53_DZE {
		type = "trade_any_vehicle";
		buy[] ={500000,"Coins"};
		sell[] ={100000,"Coins"};
	};
};
