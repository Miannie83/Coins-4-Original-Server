class Category_1001 {
	class RH_deagle {
	type = "trade_weapons";
	buy[] = {40000,"Coins"};
	sell[] = {5000,"Coins"};
	};
	class RH_Deagleg {
	type = "trade_weapons";
	buy[] = {60000,"Coins"};
	sell[] = {7000,"Coins"};
	};
	class RH_Deaglem {
	type = "trade_weapons";
	buy[] = {40000,"Coins"};
	sell[] = {5000,"Coins"};
	};
	class RH_Deaglemz {
	type = "trade_weapons";
	buy[] = {40000,"Coins"};
	sell[] = {5000,"Coins"};
	};
	class RH_Deaglemzb {
	type = "trade_weapons";
	buy[] = {40000,"Coins"};
	sell[] = {5000,"Coins"};
	};
	class RH_Deagles {
	type = "trade_weapons";
	buy[] = {40000,"Coins"};
	sell[] = {5000,"Coins"};
	};
	class RH_g17 {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_g17sd {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class RH_g18 {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class RH_g19 {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_g19t {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class RH_browninghp {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_bull {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class RH_anac {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_anacg {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_m1911 {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_m1911old {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_m1911sd {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class RH_m9 {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_m93r {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_m9c {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_m9csd {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class RH_m9sd {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class RH_usp {
	type = "trade_weapons";
	buy[] = {800,"Coins"};
	sell[] = {100,"Coins"};
	};
	class RH_uspm {
	type = "trade_weapons";
	buy[] = {900,"Coins"};
	sell[] = {113,"Coins"};
	};
	class RH_uspsd {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_mk2 {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_mk22 {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_mk22sd {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_mk22v {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_mk22vsd {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class RH_p226 {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_p226s {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_p38 {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_ppk {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_python {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class RH_tec9 {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_tt33 {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_vz61 {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class vil_B_HP {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class vil_USP {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class vil_USP45 {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class vil_USP45SD {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class vil_USPSD {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class vil_uzi {
	type = "trade_weapons";
	buy[] = {30000,"Coins"};
	sell[] = {3750,"Coins"};
	};
	class vil_uzimini {
	type = "trade_weapons";
	buy[] = {30000,"Coins"};
	sell[] = {3750,"Coins"};
	};
	class vil_uzimini_SD {
	type = "trade_weapons";
	buy[] = {40000,"Coins"};
	sell[] = {5000,"Coins"};
	};
	class vil_uzi_c {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class vil_uzi_SD {
	type = "trade_weapons";
	buy[] = {30000,"Coins"};
	sell[] = {3750,"Coins"};
	};
	class vil_MP5SD_EOTech {
	type = "trade_weapons";
	buy[] = {50000,"Coins"};
	sell[] = {6250,"Coins"};
	};
	class vil_MP5_EOTech {
	type = "trade_weapons";
	buy[] = {30000,"Coins"};
	sell[] = {3750,"Coins"};
	};
	class vil_Glock {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class vil_Glock_o {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
};