class Category_562 {
	class HMMWV_M998A2_SOV_DES_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {100000,"Coins"};
		sell[] = {25000,"Coins"};
	};
	class HMMWV_M1151_M2_CZ_DES_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {400000,"Coins"};
		sell[] = {50000,"Coins"};
	};
	class LandRover_Special_CZ_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {100000,"Coins"};
		sell[] = {25000,"Coins"};
	};
	class LandRover_MG_TK_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {60000,"Coins"};
		sell[] = {15000,"Coins"};
	};
	class UAZ_MG_TK_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {60000,"Coins"};
		sell[] = {15000,"Coins"};
	};
	class GAZ_Vodnik_DZE {
		type = "trade_any_vehicle";
		buy[] = {200000,"Coins"};
		sell[] = {25000,"Coins"};
	};
	class BTR90_HQ_DZE {
		type = "trade_any_vehicle";
		buy[] = {4000000,"Coins"};
		sell[] = {1000000,"Coins"};
	};
	class LAV25_HQ_DZE {
		type = "trade_any_vehicle";
		buy[] = {8000000,"Coins"};
		sell[] = {3500000,"Coins"};
	};
	class HMMWV_MK19_DES_EP1{
		type = "trade_any_vehicle";
		buy[] = {100000,"Coins"};
		sell[] = {25000,"Coins"};
	};
};
