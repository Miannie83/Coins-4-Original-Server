class Category_665 {
	class ItemAntibiotic {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {125,"Coins"};
	};
	class ItemBandage {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {5,"Coins"};
	};
	class ItemBloodbag {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class ItemEpinephrine {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class ItemHeatPack {
		type = "trade_items";
		buy[] = {10,"Coins"};
		sell[] = {1,"Coins"};
	};
	class ItemMorphine {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class ItemPainkiller {
		type = "trade_items";
		buy[] = {250,"Coins"};
		sell[] = {40,"Coins"};
	};
};
class Category_670 {
	class ItemAntibiotic {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {125,"Coins"};
	};
	class ItemBandage {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {5,"Coins"};
	};
	class ItemBloodbag {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class ItemEpinephrine {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class ItemHeatPack {
		type = "trade_items";
		buy[] = {10,"Coins"};
		sell[] = {1,"Coins"};
	};
	class ItemMorphine {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class ItemPainkiller {
		type = "trade_items";
		buy[] = {250,"Coins"};
		sell[] = {40,"Coins"};
	};
};
