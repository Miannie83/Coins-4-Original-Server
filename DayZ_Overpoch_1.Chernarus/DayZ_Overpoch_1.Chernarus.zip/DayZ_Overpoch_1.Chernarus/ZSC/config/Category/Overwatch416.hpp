class Category_1008 {
	class RH_hk416 {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_hk416acog {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_hk416aim {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class RH_hk416eotech {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class RH_hk416gl {
	type = "trade_weapons";
	buy[] = {10000,"Coins"};
	sell[] = {1250,"Coins"};
	};
	class RH_hk416glacog {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class RH_hk416glaim {
	type = "trade_weapons";
	buy[] = {30000,"Coins"};
	sell[] = {3750,"Coins"};
	};
	class RH_hk416gleotech {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class RH_hk416s {
	type = "trade_weapons";
	buy[] = {30000,"Coins"};
	sell[] = {3750,"Coins"};
	};
	class RH_hk416sacog {
	type = "trade_weapons";
	buy[] = {30000,"Coins"};
	sell[] = {3750,"Coins"};
	};
	class RH_hk416saim {
	type = "trade_weapons";
	buy[] = {40000,"Coins"};
	sell[] = {5000,"Coins"};
	};
	class RH_hk416sd {
	type = "trade_weapons";
	buy[] = {40000,"Coins"};
	sell[] = {5000,"Coins"};
	};
	class RH_hk416sdaim {
	type = "trade_weapons";
	buy[] = {50000,"Coins"};
	sell[] = {6250,"Coins"};
	};
	class RH_hk416sdeotech {
	type = "trade_weapons";
	buy[] = {40000,"Coins"};
	sell[] = {5000,"Coins"};
	};
	class RH_hk416sdgl {
	type = "trade_weapons";
	buy[] = {30000,"Coins"};
	sell[] = {3750,"Coins"};
	};
	class RH_hk416sdglaim {
	type = "trade_weapons";
	buy[] = {50000,"Coins"};
	sell[] = {6250,"Coins"};
	};
	class RH_hk416sdgleotech {
	type = "trade_weapons";
	buy[] = {30000,"Coins"};
	sell[] = {3750,"Coins"};
	};
	class RH_hk416seotech {
	type = "trade_weapons";
	buy[] = {30000,"Coins"};
	sell[] = {3750,"Coins"};
	};
	class RH_hk416sgl {
	type = "trade_weapons";
	buy[] = {20000,"Coins"};
	sell[] = {2500,"Coins"};
	};
	class RH_hk416sglacog {
	type = "trade_weapons";
	buy[] = {30000,"Coins"};
	sell[] = {3750,"Coins"};
	};
	class RH_hk416sglaim {
	type = "trade_weapons";
	buy[] = {40000,"Coins"};
	sell[] = {5000,"Coins"};
	};
	class RH_hk416sgleotech {
	type = "trade_weapons";
	buy[] = {40000,"Coins"};
	sell[] = {5000,"Coins"};
	};
};
