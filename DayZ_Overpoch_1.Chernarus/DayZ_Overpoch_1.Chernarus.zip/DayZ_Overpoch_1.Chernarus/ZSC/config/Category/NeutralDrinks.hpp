class Category_498 {
	class ItemSodaCoke {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemSodaPepsi {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemSodaMdew {
		type = "trade_items";
		buy[] = {60,"Coins"};
		sell[] = {30,"Coins"};
	};
	class ItemSodaR4z0r {
		type = "trade_items";
		buy[] = {60,"Coins"};
		sell[] = {30,"Coins"};
	};
	class ItemWaterbottleUnfilled {
		type = "trade_items";
		buy[] = {30,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemSodaRbull {
		type = "trade_items";
		buy[] = {60,"Coins"};
		sell[] = {30,"Coins"};
	};
	class ItemSodaOrangeSherbet {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {20,"Coins"};
	};
};
class Category_633 {
	class ItemSodaCoke {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemSodaPepsi {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemSodaMdew {
		type = "trade_items";
		buy[] = {60,"Coins"};
		sell[] = {30,"Coins"};
	};
	class ItemSodaR4z0r {
		type = "trade_items";
		buy[] = {60,"Coins"};
		sell[] = {30,"Coins"};
	};
	class ItemWaterbottleUnfilled {
		type = "trade_items";
		buy[] = {30,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemSodaRbull {
		type = "trade_items";
		buy[] = {60,"Coins"};
		sell[] = {30,"Coins"};
	};
	class ItemSodaOrangeSherbet {
		type = "trade_items";
		buy[] = {40,"Coins"};
		sell[] = {20,"Coins"};
	};
};
