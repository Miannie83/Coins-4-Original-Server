class Category_675 {
	class bulk_15Rnd_9x19_M9SD {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class bulk_17Rnd_9x19_glock17 {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class bulk_30Rnd_556x45_StanagSD {
		type = "trade_items";
		buy[] = {4000,"Coins"};
		sell[] = {500,"Coins"};
	};
	class bulk_30Rnd_9x19_MP5SD {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class bulk_ItemSandbag {
		type = "trade_items";
		buy[] = {20000,"Coins"};
		sell[] = {2500,"Coins"};
	};
	class bulk_ItemTankTrap {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {125,"Coins"};
	};
	class bulk_ItemWire {
		type = "trade_items";
		buy[] = {300,"Coins"};
		sell[] = {75,"Coins"};
	};
	class bulk_PartGeneric {
		type = "trade_items";
		buy[] = {600,"Coins"};
		sell[] = {75,"Coins"};
	};
	class CinderBlocks {
		type = "trade_items";
		buy[] = {8000,"Coins"};
		sell[] = {1000,"Coins"};
	};
	class PartPlywoodPack {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {500,"Coins"};
	};
	class MortarBucket {
		type = "trade_items";
		buy[] = {5000,"Coins"};
		sell[] = {700,"Coins"};
	};
	class PartPlankPack {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {500,"Coins"};
	};
	class ItemFuelBarrelEmpty {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {125,"Coins"};
	};
		class metal_floor_kit {
		type = "trade_items";
		buy[] = {50000,"Coins"};
		sell[] = {5000,"Coins"};
	};
};
class Category_636 {
	class bulk_15Rnd_9x19_M9SD {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class bulk_17Rnd_9x19_glock17 {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class bulk_30Rnd_556x45_StanagSD {
		type = "trade_items";
		buy[] = {4000,"Coins"};
		sell[] = {500,"Coins"};
	};
	class bulk_30Rnd_9x19_MP5SD {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class bulk_ItemSandbag {
		type = "trade_items";
		buy[] = {20000,"Coins"};
		sell[] = {2500,"Coins"};
	};
	class bulk_ItemTankTrap {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {125,"Coins"};
	};
	class bulk_ItemWire {
		type = "trade_items";
		buy[] = {300,"Coins"};
		sell[] = {75,"Coins"};
	};
	class bulk_PartGeneric {
		type = "trade_items";
		buy[] = {600,"Coins"};
		sell[] = {75,"Coins"};
	};
	class CinderBlocks {
		type = "trade_items";
		buy[] = {8000,"Coins"};
		sell[] = {1000,"Coins"};
	};
	class PartPlywoodPack {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {500,"Coins"};
	};
	class MortarBucket {
		type = "trade_items";
		buy[] = {5000,"Coins"};
		sell[] = {700,"Coins"};
	};
	class PartPlankPack {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {500,"Coins"};
	};
	class ItemFuelBarrelEmpty {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {125,"Coins"};
	};
		class metal_floor_kit {
		type = "trade_items";
		buy[] = {50000,"Coins"};
		sell[] = {5000,"Coins"};
	};
};
class Category_555 {
	class bulk_15Rnd_9x19_M9SD {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class bulk_17Rnd_9x19_glock17 {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class bulk_30Rnd_556x45_StanagSD {
		type = "trade_items";
		buy[] = {4000,"Coins"};
		sell[] = {500,"Coins"};
	};
	class bulk_30Rnd_9x19_MP5SD {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {250,"Coins"};
	};
	class bulk_ItemSandbag {
		type = "trade_items";
		buy[] = {20000,"Coins"};
		sell[] = {2500,"Coins"};
	};
	class bulk_ItemTankTrap {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {125,"Coins"};
	};
	class bulk_ItemWire {
		type = "trade_items";
		buy[] = {300,"Coins"};
		sell[] = {75,"Coins"};
	};
	class bulk_PartGeneric {
		type = "trade_items";
		buy[] = {600,"Coins"};
		sell[] = {75,"Coins"};
	};
	class CinderBlocks {
		type = "trade_items";
		buy[] = {8000,"Coins"};
		sell[] = {1000,"Coins"};
	};
	class PartPlywoodPack {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {500,"Coins"};
	};
	class MortarBucket {
		type = "trade_items";
		buy[] = {5000,"Coins"};
		sell[] = {700,"Coins"};
	};
	class PartPlankPack {
		type = "trade_items";
		buy[] = {2000,"Coins"};
		sell[] = {500,"Coins"};
	};
	class ItemFuelBarrelEmpty {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {125,"Coins"};
	};
		class metal_floor_kit {
		type = "trade_items";
		buy[] = {50000,"Coins"};
		sell[] = {5000,"Coins"};
	};
};
