class Category_663 {
	class ItemCompass {
		type = "trade_weapons";
		buy[] = {60,"Coins"};
		sell[] = {30,"Coins"};
	};
	class Binocular {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class Binocular_Vector {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemEtool {
		type = "trade_weapons";
		buy[] = {900,"Coins"};
		sell[] = {600,"Coins"};
	};
	class ItemFlashlight {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemFlashlightRed {
		type = "trade_weapons";
		buy[] = {100,"Coins"};
		sell[] = {50,"Coins"};
	};
	class ItemGPS {
		type = "trade_weapons";
		buy[] = {2000,"Coins"};
		sell[] = {100,"Coins"};
	};
	class ItemHatchet_DZE {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemKnife {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemMap {
		type = "trade_weapons";
		buy[] = {60,"Coins"};
		sell[] = {3,"Coins"};
	};
	class ItemMatchbox_DZE {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemToolbox {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemWatch {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class NVGoggles {
		type = "trade_weapons";
		buy[] = {4000,"Coins"};
		sell[] = {100,"Coins"};
	};
	class ItemCrowbar {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemMachete {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemFishingPole {
		type = "trade_weapons";
		buy[] = {200,"Coins"};
		sell[] = {100,"Coins"};
	};
};
class Category_510 {
	class ItemCompass {
		type = "trade_weapons";
		buy[] = {60,"Coins"};
		sell[] = {30,"Coins"};
	};
	class Binocular {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class Binocular_Vector {
		type = "trade_weapons";
		buy[] = {2000,"Coins"};
		sell[] = {100,"Coins"};
	};
	class ItemEtool {
		type = "trade_weapons";
		buy[] = {900,"Coins"};
		sell[] = {600,"Coins"};
	};
	class ItemFlashlight {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemFlashlightRed {
		type = "trade_weapons";
		buy[] = {100,"Coins"};
		sell[] = {50,"Coins"};
	};
	class ItemGPS {
		type = "trade_weapons";
		buy[] = {2000,"Coins"};
		sell[] = {100,"Coins"};
	};
	class ItemHatchet_DZE {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemKnife {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemMap {
		type = "trade_weapons";
		buy[] = {60,"Coins"};
		sell[] = {3,"Coins"};
	};
	class ItemMatchbox_DZE {
		type = "trade_weapons";
		buy[] = {10,"Coins"};
		sell[] = {5,"Coins"};
	};
	class ItemToolbox {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemWatch {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class NVGoggles {
		type = "trade_weapons";
		buy[] = {4000,"Coins"};
		sell[] = {100,"Coins"};
	};
	class ItemCrowbar {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemMachete {
		type = "trade_weapons";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemFishingPole {
		type = "trade_weapons";
		buy[] = {200,"Coins"};
		sell[] = {100,"Coins"};
	};
};
