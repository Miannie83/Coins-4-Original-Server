class Category_662 {
	class ItemSandbag {
		type = "trade_items";
		buy[] = {4000,"Coins"};
		sell[] = {500,"Coins"};
	};
	class ItemTankTrap {
		type = "trade_items";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
	class ItemTentOld {
		type = "trade_items";
		buy[] = {400,"Coins"};
		sell[] = {50,"Coins"};
	};
	class ItemWire {
		type = "trade_items";
		buy[] = {60,"Coins"};
		sell[] = {10,"Coins"};
	};
	class 30m_plot_kit {
		type = "trade_items";
		buy[] = {60000,"Coins"};
		sell[] = {60000,"Coins"};
	};
	class ItemVault {
		type = "trade_items";
		buy[] = {100000,"Coins"};
		sell[] = {100000,"Coins"};
	};
	class ItemTentDomed {
		type = "trade_items";
		buy[] = {600,"Coins"};
		sell[] = {75,"Coins"};
	};
	class ItemTentDomed2 {
		type = "trade_items";
		buy[] = {600,"Coins"};
		sell[] = {75,"Coins"};
	};
	class ItemLightBulb {
		type = "trade_items";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
	class ItemGenerator {
		type = "trade_items";
		buy[] = {6000,"Coins"};
		sell[] = {750,"Coins"};
	};
	class ItemComboLock{
		type = "trade_items";
		buy[] = {80000,"Coins"};
		sell[] = {10000,"Coins"};
	};
	class ItemMixOil{
		type = "trade_items";
		buy[] = {40000,"Coins"};
		sell[] = {5000,"Coins"};
	};
	class ChainSaw{
		type = "trade_weapons";
		buy[] = {100000,"Coins"};
		sell[] = {12500,"Coins"};
	};
	class ChainSawB{
		type = "trade_weapons";
		buy[] = {100000,"Coins"};
		sell[] = {12500,"Coins"};
	};
	class ChainSawG{
		type = "trade_weapons";
		buy[] = {100000,"Coins"};
		sell[] = {12500,"Coins"};
	};
	class ChainSawp{
		type = "trade_weapons";
		buy[] = {100000,"Coins"};
		sell[] = {12500,"Coins"};
	};
	class ChainSawR{
		type = "trade_weapons";
		buy[] = {100000,"Coins"};
		sell[] = {12500,"Coins"};
	};
};
class Category_508 {
	class ItemSandbag {
		type = "trade_items";
		buy[] = {4000,"Coins"};
		sell[] = {500,"Coins"};
	};
	class ItemTankTrap {
		type = "trade_items";
		buy[] = {200,"Coins"};
		sell[] = {25,"Coins"};
	};
	class ItemTentOld {
		type = "trade_items";
		buy[] = {400,"Coins"};
		sell[] = {50,"Coins"};
	};
	class ItemWire {
		type = "trade_items";
		buy[] = {60,"Coins"};
		sell[] = {30,"Coins"};
	};
	class 30m_plot_kit {
		type = "trade_items";
		buy[] = {60000,"Coins"};
		sell[] = {60000,"Coins"};
	};
	class ItemCorrugated {
		type = "trade_items";
		buy[] = {20,"Coins"};
		sell[] = {10,"Coins"};
	};
	class ItemPole {
		type = "trade_items";
		buy[] = {100,"Coins"};
		sell[] = {25,"Coins"};
	};
	class ItemVault {
		type = "trade_items";
		buy[] = {100000,"Coins"};
		sell[] = {100000,"Coins"};
	};
	class ItemTentDomed {
		type = "trade_items";
		buy[] = {600,"Coins"};
		sell[] = {50,"Coins"};
	};
	class ItemTentDomed2 {
		type = "trade_items";
		buy[] = {600,"Coins"};
		sell[] = {50,"Coins"};
	};
	class ItemLightBulb {
		type = "trade_items";
		buy[] = {200,"Coins"};
		sell[] = {15,"Coins"};
	};
	class ItemGenerator {
		type = "trade_items";
		buy[] = {6000,"Coins"};
		sell[] = {750,"Coins"};
	};
	class ItemComboLock{
		type = "trade_items";
		buy[] = {80000,"Coins"};
		sell[] = {10000,"Coins"};
	};
	class ItemMixOil{
		type = "trade_items";
		buy[] = {40000,"Coins"};
		sell[] = {2500,"Coins"};
	};
	class ChainSaw{
		type = "trade_items";
		buy[] = {100000,"Coins"};
		sell[] = {12500,"Coins"};
	};
	class ChainSawB{
		type = "trade_items";
		buy[] = {100000,"Coins"};
		sell[] = {12500,"Coins"};
	};
	class ChainSawG{
		type = "trade_items";
		buy[] = {100000,"Coins"};
		sell[] = {12500,"Coins"};
	};
	class ChainSawp{
		type = "trade_items";
		buy[] = {100000,"Coins"};
		sell[] = {12500,"Coins"};
	};
	class ChainSawR{
		type = "trade_items";
		buy[] = {100000,"Coins"};
		sell[] = {12500,"Coins"};
	};
};
