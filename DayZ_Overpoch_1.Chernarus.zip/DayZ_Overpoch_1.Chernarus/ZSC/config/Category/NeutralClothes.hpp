class Category_683 {
	class Skin_Rocker2_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorW2_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Functionary1_EP1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Haris_Press_EP1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Priest_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorWpink_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorWurban_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorWcombat_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorWdesert_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Survivor2_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Rocker1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Rocker3_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_RU_Policeman_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Pilot_EP1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Rocker4_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorW3_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
};
class Category_497 {
	class Skin_Rocker2_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorW2_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Functionary1_EP1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Haris_Press_EP1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Priest_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorWpink_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorWurban_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorWcombat_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorWdesert_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Survivor2_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Rocker1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Rocker3_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_RU_Policeman_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Pilot_EP1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Rocker4_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorW3_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
};
class Category_631 {
	class Skin_Rocker2_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorW2_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Functionary1_EP1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Haris_Press_EP1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Priest_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorWpink_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorWurban_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorWcombat_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorWdesert_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Survivor2_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Rocker1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Rocker3_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_RU_Policeman_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Pilot_EP1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Rocker4_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_SurvivorW3_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
};
