class Category_666 {
	class HandChemBlue {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class HandChemGreen {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class HandChemRed {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FlareGreen_M203 {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FlareWhite_M203 {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class HandRoadFlare {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
};
class Category_669 {
	class HandChemBlue {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class HandChemGreen {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class HandChemRed {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FlareGreen_M203 {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class FlareWhite_M203 {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class HandRoadFlare {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
};
