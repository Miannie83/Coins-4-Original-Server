class Category_644 {
	class 100Rnd_762x51_M240 {
		type = "trade_items";
		buy[] ={750,"Coins"};
		sell[] ={375,"Coins"};
	};
	class 200Rnd_556x45_M249 {
		type = "trade_items";
		buy[] ={500,"Coins"};
		sell[] ={250,"Coins"};
	};
	class 100Rnd_762x54_PK {
		type = "trade_items";
		buy[] ={1000,"Coins"};
		sell[] ={500,"Coins"};
	};
};
class Category_610 {
	class 100Rnd_762x51_M240 {
		type = "trade_items";
		buy[] ={750,"Coins"};
		sell[] ={375,"Coins"};
	};
	class 200Rnd_556x45_M249 {
		type = "trade_items";
		buy[] ={500,"Coins"};
		sell[] ={250,"Coins"};
	};
	class 100Rnd_762x54_PK {
		type = "trade_items";
		buy[] ={1000,"Coins"};
		sell[] ={500,"Coins"};
	};
};
