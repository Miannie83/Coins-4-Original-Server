class Category_607 {
class Winchester1866 {type = "trade_weapons";buy[] ={20000,"Coins"};sell[] ={10000,"Coins"};};
class MR43 {type = "trade_weapons";buy[] ={15000,"Coins"};sell[] ={5000,"Coins"};};
class Crossbow_DZ {type = "trade_weapons";buy[] ={1000,"Coins"};sell[] ={500,"Coins"};};
class M1014 {type = "trade_weapons";buy[] ={18500,"Coins"};sell[] ={7500,"Coins"};};
class Remington870_lamp {type = "trade_weapons";buy[] ={17500,"Coins"};sell[] ={7500,"Coins"};};
class LeeEnfield {type = "trade_weapons";buy[] ={20000,"Coins"};sell[] ={7500,"Coins"};};
};
class Category_641 {
class Winchester1866 {type = "trade_weapons";buy[] ={20000,"Coins"};sell[] ={10000,"Coins"};};
class MR43 {type = "trade_weapons";buy[] ={15000,"Coins"};sell[] ={5000,"Coins"};};
class Crossbow_DZ {type = "trade_weapons";buy[] ={1000,"Coins"};sell[] ={500,"Coins"};};
class M1014 {type = "trade_weapons";buy[] ={18500,"Coins"};sell[] ={7500,"Coins"};};
class Remington870_lamp {type = "trade_weapons";buy[] ={17500,"Coins"};sell[] ={7500,"Coins"};};
class LeeEnfield {type = "trade_weapons";buy[] ={20000,"Coins"};sell[] ={7500,"Coins"};};
};