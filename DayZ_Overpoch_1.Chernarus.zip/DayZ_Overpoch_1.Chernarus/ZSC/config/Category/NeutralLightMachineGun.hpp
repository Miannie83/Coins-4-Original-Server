class Category_603 {
class M249_EP1_DZ {type = "trade_weapons";buy[] ={60000,"Coins"};sell[] ={17500,"Coins"};};
class M240_DZ {type = "trade_weapons";buy[] ={65000,"Coins"};sell[] ={20000,"Coins"};};
class Mk_48_DZ {type = "trade_weapons";buy[] ={65000,"Coins"};sell[] ={20000,"Coins"};};
class Pecheneg_DZ {type = "trade_weapons";buy[] ={62500,"Coins"};sell[] ={20000,"Coins"};};
};
class Category_638 {
class M249_EP1_DZ {type = "trade_weapons";buy[] ={60000,"Coins"};sell[] ={17500,"Coins"};};
class M240_DZ {type = "trade_weapons";buy[] ={65000,"Coins"};sell[] ={20000,"Coins"};};
class Mk_48_DZ {type = "trade_weapons";buy[] ={65000,"Coins"};sell[] ={20000,"Coins"};};
class Pecheneg_DZ {type = "trade_weapons";buy[] ={62500,"Coins"};sell[] ={20000,"Coins"};};
};
