class Category_575 {
	class Skin_CZ_Special_Forces_GL_DES_EP1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Drake_Light_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Soldier_Sniper_PMC_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_FR_OHara_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_FR_Rodriguez_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_CZ_Soldier_Sniper_EP1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Graves_Light_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Soldier_Bodyguard_AA12_PMC_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Camo1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Rocket_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Sniper1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Soldier1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Soldier_TL_PMC_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
		
	class Skin_Bandit1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
		class Skin_Bandit2_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
		class Skin_BanditW1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
		class Skin_BanditW2_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
		class Skin_GUE_Commander_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
		class Skin_GUE_Soldier_2_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
		class Skin_GUE_Soldier_CO_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
		class Skin_GUE_Soldier_Crew_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
		class Skin_GUE_Soldier_Sniper_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
		class Skin_Ins_Soldier_GL_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
		class Skin_TK_INS_Soldier_EP1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
		class Skin_TK_INS_Warlord_EP1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	


};
