class Category_529 {
	class HandGrenade_west {
		type = "trade_items";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class 1Rnd_HE_M203 {
		type = "trade_items";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class HandGrenade_east {
		type = "trade_items";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
};
