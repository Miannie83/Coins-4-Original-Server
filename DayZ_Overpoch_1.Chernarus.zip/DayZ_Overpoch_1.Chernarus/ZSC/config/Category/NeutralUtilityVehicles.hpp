class Category_591 {
	class SUV_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={50000,"Coins"};
		sell[] ={15000,"Coins"};
	};
	class SUV_Blue {
		type = "trade_any_vehicle";
		buy[] ={50000,"Coins"};
		sell[] ={15000,"Coins"};
	};
	class SUV_Charcoal {
		type = "trade_any_vehicle";
		buy[] ={50000,"Coins"};
		sell[] ={15000,"Coins"};
	};
	class SUV_Green {
		type = "trade_any_vehicle";
		buy[] ={50000,"Coins"};
		sell[] ={15000,"Coins"};
	};
	class SUV_Orange {
		type = "trade_any_vehicle";
		buy[] ={50000,"Coins"};
		sell[] ={15000,"Coins"};
	};
	class SUV_Pink {
		type = "trade_any_vehicle";
		buy[] ={50000,"Coins"};
		sell[] ={15000,"Coins"};
	};
	class SUV_Red {
		type = "trade_any_vehicle";
		buy[] ={50000,"Coins"};
		sell[] ={15000,"Coins"};
	};
	class SUV_Silver {
		type = "trade_any_vehicle";
		buy[] ={50000,"Coins"};
		sell[] ={15000,"Coins"};
	};
	class SUV_White {
		type = "trade_any_vehicle";
		buy[] ={50000,"Coins"};
		sell[] ={15000,"Coins"};
	};
	class SUV_Yellow {
		type = "trade_any_vehicle";
		buy[] ={50000,"Coins"};
		sell[] ={15000,"Coins"};
	};
	class SUV_Camo {
		type = "trade_any_vehicle";
		buy[] ={50000,"Coins"};
		sell[] ={15000,"Coins"};
	};
	class UAZ_CDF {
		type = "trade_any_vehicle";
		buy[] ={50000,"Coins"};
		sell[] ={15000,"Coins"};
	};
};